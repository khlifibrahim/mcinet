import React from 'react'

function unauthorized() {
  return (
    <div className='flex items-center justify-center font-bold text-3xl'>Profile not authorized</div>
  )
}

export default unauthorized